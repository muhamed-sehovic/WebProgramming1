<?php

class ExamDao
{

  private $conn;

  /**
   * constructor of dao class
   */
  public function __construct()
  {
    try {
      /** TODO
       * List parameters such as servername, username, password, schema. Make sure to use appropriate port
       */
      $username = "webfinal_db_user2";
      $password = "webFinal3006";
      $dns = "mysql:host=db1.ibu.edu.ba; dbname=webfinal_db_3006; charset=utf8;";



      /** TODO
       * Create new connection
       */
      $this->conn=new PDO($dns, $username, $password);


      echo "Connected successfully";
    } catch (PDOException $e) {
      echo "Connemployees_performance_reportection failed: " . $e->getMessage();
    }
  }

  /** TODO
   * Implement DAO method used to get employees performance report
   */
  public function employees_performance_report() {
    $query = "SELECT e.employeeNumber AS employee_id,
              CONCAT(e.firstName, e.lastName) AS employeeName,
              e.email AS email,
              SUM(p.amount) AS total
              FROM employees e
              JOIN customers c ON c.salesRepEmployeeNumber = e.employeeNumber
              JOIN payments p ON p.customerNumber = c.customerNumber
              GROUP BY e.employeeNumber, e.firstName, e.lastName, e.email
              ORDER BY total DESC
    ";

    $stmt = $this->conn->prepare($query);
    $stmt->execute();
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}


  /** TODO
   * Implement DAO method used to delete employee by id
   */
  public function delete_employee($employee_id) {
  $query = "DELETE FROM employees WHERE employeeNumber = :employee_id";
  
  $stmt = $this->conn->prepare($query);
  $stmt->bindParam(':employee_id', $employee_id, PDO::PARAM_INT);
  return $stmt->execute();
}


  /** TODO
   * Implement DAO method used to edit employee data
   */
    public function edit_employee($employee_id, $data) {
    $query = "UPDATE employees SET firstName = :firstName, lastName = :lastName, email = :email WHERE employeeNumber = :id";
    $stmt = $this->conn->prepare($query);
    return $stmt->execute([
      ':first_name' => $data['firstName'],
      ':last_name' => $data['lastName'],
      ':email' => $data['email'],
      ':id' => $employee_id
    ]);
  }
  

  /** TODO
   * Implement DAO method used to get orders report
   */
  public function get_orders_report() {
    $query = "SELECT o.orderNumber, o.orderDate,
                CONCAT(c.contactFirstName, c.contactLastName) AS customerName,
                CONCAT(e.firstName, e.lastName) AS employeeName,
                SUM(od.quantityOrdered * od.priceEach) AS totalAmount
                FROM orders o
                JOIN customers c ON o.customerNumber = c.customerNumber
                LEFT JOIN employees e ON c.salesRepEmployeeNumber = e.employeeNumber
                JOIN orderdetails od ON o.orderNumber = od.orderNumber
                GROUP BY o.orderNumber
                ORDER BY o.orderDate DESC";

    $stmt = $this->conn->prepare($query);
    $stmt->execute();
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}


  /** TODO
   * Implement DAO method used to get all products in a single order
   */
  public function get_order_details($order_id) {
    $query = "SELECT o.orderNumber, p.productCode, p.productName AS name, od.quantityOrdered AS quantity, od.priceEach AS price
              FROM orders o
              JOIN orderdetails od ON od.orderNumber = o.orderNumber
              JOIN products p ON od.productCode = p.productCode
              WHERE o.orderNumber = ?";

    $stmt = $this->conn->prepare($query);
    $stmt->execute([$order_id]);
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}
};